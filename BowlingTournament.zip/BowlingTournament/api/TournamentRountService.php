<?php

$projectRoot = filter_input(INPUT_SERVER, 'DOCUMENT_ROOT') . '/project/BowlingTournament';
require_once ($projectRoot . '/db/tournamentAccessor.php');

$method = filter_input(INPUT_SERVER, 'REQUEST_METHOD'); // $_SERVER['REQUEST_METHOD']
if ($method === "GET") {
    doGet();
}

function doGet() {
    if (!filter_has_var(INPUT_GET, 'itemid')) {
        try {
            $tia = new tournamentAccessor();
            $results = $tia->getAllRounds(); // these are objects
            $results = json_encode($results, JSON_NUMERIC_CHECK);
            echo $results;
        } catch (Exception $e) {
            echo "ERROR " . $e->getMessage();
        }
    }
}
