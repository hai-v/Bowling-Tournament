<?php

$projectRoot = filter_input(INPUT_SERVER, 'DOCUMENT_ROOT') . '/project/BowlingTournament';
require_once ($projectRoot . '/db/GameAccessor.php');
require_once ($projectRoot . '/ChromePhp.php');

$method = filter_input(INPUT_SERVER, 'REQUEST_METHOD'); // $_SERVER['REQUEST_METHOD']
if ($method === "POST") {
    doPOST();
}

function doPOST() {
    if (!filter_has_var(INPUT_GET, 'itemid')) {
        try {
            $body = file_get_contents('php://input');
            $contents = json_decode($body, true);
            ChromePhp::log($contents);
            $mua = new GameAccessor();
            $results = $mua->getSpecificGame($contents); // these are objects
            $results = json_encode($results, JSON_NUMERIC_CHECK);
            echo $results;
        } catch (Exception $e) {
            echo "ERROR " . $e->getMessage();
        }
    }
}


