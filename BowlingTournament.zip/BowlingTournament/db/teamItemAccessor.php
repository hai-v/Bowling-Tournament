<?php

$projectRoot = $_SERVER['DOCUMENT_ROOT'] . '/project/BowlingTournament';
require_once 'ConnectionManager.php';
require_once ($projectRoot . '/objects/Team.php');

class teamItemAccessor {

    private $deleteStatementString = "delete from team where teamID = :teamID";
    private $insertStatementString = "insert INTO team values (:teamID, :teamName, :earnings)";
    private $updateStatementString = "update team set earnings = :earnings, earnings = :earnings where teamID = :teamID";
    private $conn = NULL;
    private $deleteStatement = NULL;
    private $insertStatement = NULL;
    private $updateStatement = NULL;

    public function __construct() {
        $cm = new ConnectionManager();

        $this->conn = $cm->connect_db();
        if (is_null($this->conn)) {
            throw new Exception("no connection");
        }

        $this->deleteStatement = $this->conn->prepare($this->deleteStatementString);
        if (is_null($this->deleteStatement)) {
            throw new Exception("bad statement: '" . $this->deleteStatementString . "'");
        }

        $this->insertStatement = $this->conn->prepare($this->insertStatementString);
        if (is_null($this->insertStatement)) {
            throw new Exception("bad statement: '" . $this->getAllStatementString . "'");
        }

        $this->updateStatement = $this->conn->prepare($this->updateStatementString);
        if (is_null($this->updateStatement)) {
            throw new Exception("bad statement: '" . $this->updateStatementString . "'");
        }
    }

    private function getItemsByQuery($selectString) {
        $result = [];
        
        try {
            $stmt = $this->conn->prepare($selectString);
            $stmt->execute();
            $dbresults = $stmt->fetchAll(PDO::FETCH_ASSOC);

            foreach ($dbresults as $r) {
                $teamID = $r['teamID'];
                $teamName = $r['teamName'];
                $earnings = $r['earnings'];
                $obj = new Team($teamID, $teamName, $earnings);
                array_push($result, $obj);
            }
        } catch (Exception $e) {
            $result = [];
        } finally {
            if (!is_null($stmt)) {
                $stmt->closeCursor();
            }
        }

        return $result;
    }

// end function getItemsByQuery

    public function getAllItems() {
        return $this->getItemsByQuery("SELECT * FROM team");
    }
    
// end function getAllItems    
    
    public function getSpecificTeam($teamID){
        if (strcmp($teamID, "ALL") == 0) {
            $specificMatchup = "select * from team";
        } else {
            $specificMatchup = "select * from team WHERE teamID ='" . $teamID . "'";
        }
        ChromePhp::log($specificMatchup);
        return $this->getItemsByQuery($specificMatchup);
    }
   
// end function getSpecificTeam


}
