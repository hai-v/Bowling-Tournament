<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Guest View</title>
        <script src="Matchup.js"></script>
        <link rel="stylesheet" href="mainStyleSheet.css">
    </head>
    <body>
        <h1>View Matches</h1>
        <form action="index.php">
            <button type="submit" class="MATCHUPHOME">Home</button>
        </form>
        <button id="matchButton">Go!</button>
        <select id="tournamentRound" name="tournamentRound">
        </select>
        <table class="hidden" id="Matches">
            <tr>
                <th>matchID</th>
                <th>roundID</th>
                <th>matchgroup</th>
                <th>teamID</th>
                <th>score</th>
                <th>ranking</th>
            </tr>
        </table>
    </body>
</html>
