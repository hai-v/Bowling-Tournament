<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>View Payouts</title>
        <script src="Payouts.js"></script>
        <link rel="stylesheet" href="mainStyleSheet.css">
    </head>
    <body>
        <h1>View Payouts</h1>
        <form action="index.php">
            <button type="submit" class="PAYOUTHOME">Home</button>
        </form>
        <button id="PayoutButton">Go!</button>
        <select id="Payout" name="Payout">
        </select>

        <table class="hidden">
            <tr>
                <th>Team ID</th>
                <th>Team Name</th>
                <th>Amount Won</th>
            </tr>
        </table>
    </body>
</html>
