window.onload = function () {
    document.querySelector("#matchButton").addEventListener("click", getMatchData);
    document.querySelector("table").addEventListener("click", handleRowClick);


    tournamentRound();
};




function tournamentRound() {
    var url = "TournamentRountService/TournamentRound"
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            var resp = xmlhttp.responseText;
            if (resp.search("ERROR") >= 0) {
                alert("oh no... see console for error");
                console.log(resp);
            } else {
                fillSelect(xmlhttp.responseText);
                console.log(xmlhttp.responseText);
            }
        }
    };
    xmlhttp.open("GET", url, true);
    xmlhttp.send();
}

function fillSelect(text) {
    var data = JSON.parse(text);
    var theSelect = document.querySelector("#tournamentRound");
    var html = "<option value='ALL'>ALL</option>";
    for (var i = 0; i < data.length; i++) {
        var temp = data[i];
        html += "<option value='" + temp.roundID + "'>" + temp.roundID + "</option>";
    }
    theSelect.innerHTML = html;
}

function getMatchData() {
    var str = document.querySelector("#tournamentRound").value;
    console.log(str);
    var url = "MatchupService/Matchup";
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            var resp = xmlhttp.responseText;
            if (resp.search("ERROR") >= 0) {
                alert("oh no... see console for error");
                console.log(resp);
            } else {
                showTable();
                buildTable(xmlhttp.responseText);
            }
        }
    };
    xmlhttp.open("POST", url, true);
    xmlhttp.send(JSON.stringify(str));

}

function showTable() {
    var x = document.querySelector("table");
    x.classList.remove("hidden");
}

function buildTable(text) {
    var data = JSON.parse(text);
    if (data.length > 0) { //If there are games in the table
        let matchTable = document.querySelector("table");
        matchTable.innerHTML = "";
        let html = "<tr class=scoreTableHeader>\n\
            <th>Match ID</th>\n\
            <th>Round ID</th>\n\
            <th>Matchgroup</th>\n\
            <th>Team ID</th>\n\
            <th>Score</th>\n\
            <th>Ranking</th>\n\
        </tr>";
        for (let i = 0; i < data.length; i++) {
            let temp = data[i];
            html += "<tbody><tr class=scoreEvent id=" + i + ">";
            html += "<td id='matchID'>" + temp.matchID + "</td>";
            html += "<td>" + temp.roundID + "</td>";
            html += "<td>" + temp.matchGroup + "</td>";
            html += "<td>" + temp.teamID + "</td>";
            html += "<td>" + temp.score + "</td>";
            html += "<td>" + temp.ranking + "</td>";
            html += "<tbody id=gameData" + i + " name=game>";
            html += "</tr></tbody>";
            matchTable.innerHTML = html;
        }
    }
}



function clearSelections() {
    var trs = document.querySelectorAll("tr");
    for (var i = 0; i < trs.length; i++) {
        trs[i].classList.remove("highlighted");
    }
}

function handleRowClick(e) {
    //add style to parent of clicked cell
    clearSelections();
    e.target.parentElement.classList.add("highlighted");
    getTeams();
}

function getTeams() {
    var str = document.querySelector(".highlighted").querySelector("#matchID").innerHTML;
    console.log(str);
    var url = "MatchupService/Matchup/" + str;
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            var resp = xmlhttp.responseText;
            if (resp.search("ERROR") >= 0) {
                alert("oh no... see console for error");
                console.log(resp);
            } else {
                showTeams(xmlhttp.responseText, str);
            }
        }
    };
    xmlhttp.open("GET", url, true);
    xmlhttp.send();
}

function showTeams(text, matchID) {
    let data = JSON.parse(text);
    //console.log(data);
    if (data.length >= 1) { //If there are teams to score for do the following
        let gameData = document.querySelector("#gameData" + matchID);
        gameData.innerHTML = "";
        html = "<tr id=gameDataHeader name=gameRow><th>Scores for match" + matchID +"</th></tr>";
        for (var i = 0; i < data.length; i++) {
            document.querySelectorAll("[name=scores" + i + "]");
            let temp = data[i];
            let balls = "";
            temp.balls === null ? balls = [] : balls = temp.balls.split(",");
            console.log(balls.length);
            html += "<tr id=gameRecord" + matchID + " name=gameRow>";
            html += "<td class=teamNameCell>" + temp.teamObj.teamName + "</td>";
            for (var x = 0; x < 20; x+=2) {
                html += "<td><div class=frames>" + temp.balls[x] +"</td></div>";
            }
        }
        html += "</tr>";
        html += "</tbody>";
        gameData.innerHTML = html;
    }//end if checking if there are teams in a game
    else { //If there are no teams to score display a message and reload matchup table
        alert("All games have been scored for. Getting all matches.");
        getMatchData();
    }
}