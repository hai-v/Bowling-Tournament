<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>View Players</title>
        <script src="Teams.js"></script>
        <link rel="stylesheet" href="mainStyleSheet.css">
    </head>
    <body>
        <h1>View Players</h1>
        <form action="index.php">
            <button type="submit" class="TEAMHOME">Home</button>
        </form>
        <button id="PlayerButton">Go!</button>
        <select id="Players" name="Players">
        </select>
        
        <table class="hidden">
            <tr>
                <th>Player ID</th>
                <th>Team ID</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Hometown</th>
                <th>Province</th>
            </tr>
        </table>
    </body>
</html>
