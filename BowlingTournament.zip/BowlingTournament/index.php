<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Guest View</title>
        <link rel="stylesheet" href="mainStyleSheet.css">
    </head>
    <body>
        <h1>Main Form</h1>
        <form action="ViewMatchup.php">
            <button type="submit" class="BUTTON">View Matchups</button>
        </form>
        <form action="ViewPayouts.php">
            <button type="submit" class="BUTTON">View Payouts</button>
        </form>
        <form action="ViewTeams.php">
            <button type="submit" class="BUTTON">View Players</button>
        </form>
    </body>
</html>
