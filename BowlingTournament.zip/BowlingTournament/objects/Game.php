<?php

class Game implements JsonSerializable {

    private $gameID;
    private $matchID;
    private $gameNumber;
    private $gameStatusID;
    private $balls;
    private $score;
    private $teamObj;

    public function __construct($gameID, $gameNumber, $matchID, $gameStatusID, $balls, $score, $teamObj) {
        $this->gameID = $gameID;
        $this->matchID = $matchID;
        $this->balls = $balls;
        $this->score = $score;
        $this->gameNumber = $gameNumber;
        $this->gameStatusID = $gameStatusID;
        $this->teamObj = $teamObj;
    }

    public function getGameID() {
        return $this->gameID;
    }

    public function getMatchID() {
        return $this->matchID;
    }

    public function getGameNumber() {
        return $this->gameNumber;
    }

    public function getGameStatusID() {
        return $this->gameStatusID;
    }

    public function getBalls() {
        return $this->balls;
    }

    public function getScore() {
        return $this->score;
    }

    public function setGameStatusID($gameStatusID) {
        $this->gameStatusID = $gameStatusID;
    }

    public function setBalls($balls) {
        $this->balls = $balls;
    }

    public function setScore($score) {
        $this->score = $score;
    }

    public function jsonSerialize() {
        return get_object_vars($this);
    }

}
?> 
