window.onload = function () {
    document.querySelector("#PlayerButton").addEventListener("click", getPlayerData);

    players();
};

function players() {
    var url = "TeamService/Teams"
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            var resp = xmlhttp.responseText;
            if (resp.search("ERROR") >= 0) {
                alert("oh no... see console for error");
                console.log(resp);
            } else {
                fillSelect(xmlhttp.responseText);
                console.log(xmlhttp.responseText);
            }
        }
    };
    xmlhttp.open("GET", url, true);
    xmlhttp.send();
}

function fillSelect(text) {
    var data = JSON.parse(text);
    var theSelect = document.querySelector("#Players");
    var html = "<option value='ALL'>ALL</option>";
    for (var i = 0; i < data.length; i++) {
        var temp = data[i];
        html += "<option value='" + (i + 1) + "'>" + temp.teamName + "</option>";
    }
    theSelect.innerHTML = html;
}

function getPlayerData() {
    var str = document.querySelector("#Players").value;
    console.log(str);
    var url = "PlayerService/Players";
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            var resp = xmlhttp.responseText;
            if (resp.search("ERROR") >= 0) {
                alert("oh no... see console for error");
                console.log(resp);
            } else {
                showTable();
                buildTable(xmlhttp.responseText);
            }
        }
    };
    xmlhttp.open("POST", url, true);
    xmlhttp.send(JSON.stringify(str));

}

function showTable() {
    var x = document.querySelector("table");
    x.classList.remove("hidden");
}

function buildTable(text) {
    var data = JSON.parse(text);
    var theTable = document.querySelector("table");
    var html = theTable.querySelector("tr").innerHTML;
    for (var i = 0; i < data.length; i++) {
        var temp = data[i];
        html += "<tr  id='tr" + i + "'>";
        html += "<td>" + temp.playerID + "</td>";
        html += "<td>" + temp.teamID + "</td>";
        html += "<td>" + temp.firstName + "</td>";
        html += "<td>" + temp.lastName + "</td>";
        html += "<td>" + temp.hometown + "</td>";
        html += "<td>" + temp.province + "</td>";
        html += "<div class='Team'></div>"
        html += "</tr>";
    }
    theTable.innerHTML = html;
    for (var i = 0; i < data.length; i++) {
        document.querySelector("#tr" + i).addEventListener("click", getTeams);
    }
}

function getTeams(){
    
}

function showTeams() {
    console.log("YS");
}
