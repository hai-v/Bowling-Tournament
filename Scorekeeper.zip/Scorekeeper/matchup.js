let matchID; //Global variable to hold the matchID in the row
let rowID; //Global variable to hold the ID from match row
let rowIndex; //Global variable to store rows for number of games in a match

window.onload = function () {
    //Add event listener to button
    document.querySelector("#GetButton").addEventListener("click", getAllMatches);
    //Call ftn populateRounds to get roundID's
    //populateRounds();
    //Add changed event for select box to filter matches by round
    //document.querySelector("#rounds").addEventListener("change", getRound);
    //Call ftn to getAllMatches
    getAllMatches();
}

function populateRounds() {
    var url = "tournamentService/tournaments";
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            var resp = xmlhttp.responseText;
            if (resp.search("ERROR") >= 0) {
                alert("Error loading database");
            } else {
               //Call ftn sending in JSON data 
                buildRoundOptions(xmlhttp.responseText);
            }
        }
    };
    xmlhttp.open("GET", url, true);
    xmlhttp.send();
}

/* 
 * @param {type} JSON data from tournamentAccessor
 * Loop through JSON data and update the dropdown with tournament rounds
 * @returns null
 */
function buildRoundOptions(text) {
    let data = JSON.parse(text);
    let rounds = document.querySelector("#rounds");
    let html = "";
    for (let i = 0; i < data.length; i++) {
        html += "<option>";
        html += data[i].roundID;
        html += "</option>";
    }
    rounds.innerHTML += html;
}

/*
 * @param {type} event
 * Get roundID from select option
 */
function getRound(e) {
    let roundID = e.srcElement.value;
    //Call ftn to get matches by a specific round
    getMatchesByRound(roundID);
}


/*
 * @param {type} send in the roundID from the select dropdown
 */
function getMatchesByRound(roundID) {
    rowIndex = 0;
    let url = "matchupService/matchups/" + roundID;
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            var resp = xmlhttp.responseText;
            if (resp.search("ERROR") >= 0) {
                alert("Error loading database.");
            } else {
                //Call ftn sending in JSON data to populate matches
                buildMatches(resp);
            }
        }
    };
    xmlhttp.open("GET", url, true);
    xmlhttp.send();
}


function getAllMatches() {
    rowIndex = 0;
    let url = "matchupService/matchups";
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            var resp = xmlhttp.responseText;
            if (resp.search("ERROR") >= 0) {
                alert("oh no... see console for error");
            } else {
                //Send in JSON data to populate matches
                buildMatches(xmlhttp.responseText);
            }
        }
    };
    xmlhttp.open("GET", url, true);
    xmlhttp.send();
}

function buildMatches(text) {
    let data = JSON.parse(text);
    if (data.length > 0) { //If there are matches returned from database do the following:
        let matchTable = document.querySelector("table");
        matchTable.innerHTML = ""; //Reset the table html
        let html = "<tr class=scoreTableHeader><th>Match Number</th><th>Round ID</th><th>Matchgroup</th><th>Team ID</th><th>Score</th></tr>"; //Create tr with headers
        for (let i = 0; i < data.length; i++) { //Loop through the data from database, create rows and output data
            let temp = data[i];
            html += "<tbody><tr class=scoreEvent id=" + i + ">";
            html += "<td>" + temp.matchID + "</td>";
            html += "<td>" + temp.roundID + "</td>";
            html += "<td>" + temp.matchGroup + "</td>";
            html += "<td>" + temp.teamID + "</td>";
            html += "<td>" + temp.score + "</td>";
            html += "<tbody id=gameData" + i + " name=game>";
            html += "</tr></tbody>";
            matchTable.innerHTML = html; //Update the matchTable html
        }//End loop
        let trs = document.querySelectorAll(".scoreEvent");
        for (var i = 0; i < trs.length; i++) { //Loop through all the rows and add event displayGame
            trs[i].addEventListener("click", displayGame);
        }
    } else { //If there are no games in the matches returned from the database show display a message and call ftn to getAllMatches
        alert("No games to score this round. Getting all games.");
        getAllMatches();
    }
}

function displayGame(e) {
    //Get the matchID from the td in the row
    matchID = e.target.parentElement.cells[0].outerText;
    //Get the rowID 
    rowID = e.path[1].id;
    //Call ftn to get teams for match calling matchup accessor
    getTeamsForMatch(matchID, rowID);
}

function getTeamsForMatch(matchID, rowID) {
    let url = "matchupService/matchups/" + matchID;
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            var resp = xmlhttp.responseText;
            if (resp.search("ERROR") >= 0) {
                alert("Database Error.");
            } else {
                //Call ftn to buildGameTable sending in the teams for a game and rowID
                buildGameTable(resp, rowID);
            }
        }
    };
    xmlhttp.open("GET", url, true);
    xmlhttp.send();
}

/*
 * @param {type} JSON data returned from matchupAccessor and the rowID from the row
 * Get roundID from select option
 */
function buildGameTable(text, rowID) {
    let data = JSON.parse(text);
    if (data.length >= 1) { //If there are teams to score for do the following:
        let gameData = document.querySelector("#gameData" + rowID);
        gameData.innerHTML = ""; //Reset the HTML for the table
        html = "<tr id=gameDataHeader name=gameRow class=scoreHeader><th>Team</th>"
                + "<th>Frame 1</th><th>Frame 2</th></th><th>Frame 3</th><th>Frame 4</th>" +
                "<th>Frame 5</th><th>Frame 6</th><th>Frame 7</th><th>Frame 8</th><th>Frame 9</th><th>Frame 10</th><th>Update Score</th></tr>";
        //Loop through all the games in a match
        for (var i = 0; i < data.length; i++) {
            document.querySelectorAll("[name=scores" + i + "]");
            let temp = data[i];
            let balls = "";
            //If the teams balls are null set balls to an empty array, else set balls to an array split by a comma delimeter
            temp.balls === null ? balls = [] : balls = temp.balls.split(",");
            let ballIndex = 0; //Set ballIndex to 0 this is to ouput the correct balls into the input fields
            html += "<tr id=gameRecord" + rowID + " name=gameRow>"; //Add the gameID, gameStatusID and team name
            html += "<td class=hidden>" + temp.gameID + "</td>";
            html += "<td class=hidden>" + temp.gameStatusID + "</td>";
            html += "<td class=teamNameCell>" + temp.team.teamName + "</td>";
            for (var x = 0; x < 10; x++) { //Loop through the number of frames for a bowling game
                html += "<td><div class=frames>";
                if (x < 9) { //If you are on frame 1-9 have 
                    html += "<div class=score1><input name=scores" + rowIndex + " maxlength=1 ";
                    //if the current frame is less than the ball array value set the inputs to the ball values, otherwise have an empty input
                    x < balls.length ? html += "value=" + balls[ballIndex] + "></input></div>" : html += "></input></div>";
                    html += "<div class=score2><input name=scores" + rowIndex + " maxlength=1 ";
                    x < balls.length ? html += "value=" + balls[ballIndex + 1] + "></input></div>" : html += "></input></div>";
                } else { //If you are on the last frame have 3 inputs instead of 2 and hide the last input
                    html += "<div class=bonus1><input name=scores" + rowIndex + " maxlength=1 class=frame10Input></input></div>";
                    html += "<div class=bonus2><input name=scores" + rowIndex + " class=bonusscore" + i + " id=frame10Input2 maxlength=1></input></div>";
                    html += "<div class=hidden><input name=scores" + rowIndex + " class=bonusscore" + i + " maxlength=1></input></div>";
                }
                //Add a p tag to every frame with an error
                html += "<div class=totalScore><p name=error" + rowIndex + " class=error></p></div></td></div>";
                ballIndex += 2; //Increment ballIndex by 2
            }
            html += "<td><button id=updateScore" + i + " class=updateScorebtn name=" + rowIndex + ">Update Score</button></td>"; //Add a btn to every row for game
            rowIndex++; //Increase row Index by 1
        }
        html += "</tr>";
        html += "</tbody>";
        gameData.innerHTML = html; //Update html for gameTable
        hideRows(rowID); //Call ftn hideRows sending in the rowID
        let frame10scores = document.querySelectorAll("[class=frame10Input]"); //Select all the 
        let frame10scores2 = document.querySelectorAll("[id=frame10Input2]");
        let btns = document.querySelectorAll(".updateScorebtn");
        for (var i = 0; i < btns.length; i++) {
            btns[i].addEventListener("click", inputScore);
            frame10scores[i].addEventListener("input", enableInputForStrike);
            frame10scores2[i].addEventListener("input", enableInputForSpare);
        }
    }//end if checking if there are teams in a game
    else { //If there are no teams to score display a message and get all matchups
        alert("All games have been scored for. Getting all matches.");
        //Call ftn to getAllMatches
        getAllMatches();
    }
}
/*
 * @param {type} Send the rowID for the current match
 * Get roundID from select option
 */
function hideRows(rowID) {
    let trs = document.querySelectorAll("[name=game]");
    for (var i = 0; i < trs.length; i++) { //Loop through all of the trs in the gameTable if they don't equal the ID that was sent in hide them
        if (i === Number(rowID)) {
            document.querySelector("#gameData" + i).classList.remove("hidden");
        } else {
            document.querySelector("#gameData" + i).classList.add("hidden");
        }
    }
}

function inputScore(e) {
    let gameID = e.path[2].cells[0].innerHTML; //Get the gameID from the current row
    let gameObj = { 
        "gameID": gameID,
        "matchID": null,
        "gameNumber": null,
        "gameStatusID": 'INPROGRESS',
        "balls": [],
        "score": [0, 0, 0, 0, 0, 0, 0, 0, 0],
        "team": null
    };
    let valid = validateScore(e.target.name, gameObj);
    if (valid) { //If valid was valid call ftn to updateScore, and updateGame
        updateScores(e.target.name, gameObj);
        updateGame(gameObj);
    }
}

/*
 * @param {type} Send the currentTeam, and gameObj
 * return a boolean
 */
function validateScore(currentTeam, gameObj) {
    let balls = document.querySelectorAll("[name=scores" + currentTeam + "]"); //Store all the inputs from the current row into an array
    let valid = true;
    let errorIndex = 0; //Initiliaze errorIndex to 0
    for (let i = 0; i <= balls.length - 5; i += 2) { //Loop through the first 9 frames
        let ball1Regex = new RegExp(/^[\Xx,\d,]?$/, 'i');
        let ball2Regex = new RegExp(/^[\/,\d,]?$/, 'i');
        if (!getPreviousInputs(i, balls)) { //Call ftn to getPreviousInputs if false break out of the loop
            valid = false;
            break;
        } else if (!ball1Regex.test(balls[i].value) || !ball2Regex.test(balls[i + 1].value)) { //If either regex for both inputs fail break out of the loop
            valid = false;
            break;
        } else if (balls[i].value.toUpperCase() === "X" && balls[i + 1].value !== "") { //If the first ball in a frame is a strike and the second input is not empty break return false
            valid = false;
            break;
        } else if (balls[i].value === "" && balls[i + 1].value !== "") { //If the first ball in a frame is empty and the second ball in a frame is not empty break out of the loop return false
            valid = false;
            break;
        } else if (balls[i].value.toUpperCase() !== "X" && balls[i].value !== "") { //If the first ball is NOT a strike and the second ball is NOT empty do the following:
            ball2Regex = RegExp(/^[\/,\d]/, 'i'); //Declare a new regex for the second ball for the frame
            if (!ball2Regex.test(balls[i + 1].value) || Number(balls[i].value) + Number(balls[i + 1].value) >= 10) { /* If the regex fails for the second ball
                                                                                                                                                                 * Or the combined total for both balls in the frame is greater than 10
                                                                                                                                                                     return false, break out loop */
                valid = false;
                break;
            }
        }
        gameObj.balls[i] = balls[i].value; //Set gameObj balls to all the balls from the input
        gameObj.balls[i + 1] = balls[i + 1].value;
        gameObj.balls[balls.length - 3] = balls[balls.length - 3].value;
        gameObj.balls[balls.length - 2] = balls[balls.length - 2].value;
        gameObj.balls[balls.length - 1] = balls[balls.length - 1].value;
        errorIndex++; //increment errorIndex
    }//end loop
    //If valid is true and frame 10 inputs or not empty call the ftn to validateFrame10, otherwise return valid
    valid && balls[balls.length - 3].value.toUpperCase() != "" || balls[balls.length - 2].value != "" ? valid = validateFrame10(balls) : valid;
    if (!valid) { //If it's not valid return display an error message for the frame that has an error
        alert("Error updating game.");
        document.querySelectorAll("[name=error" + currentTeam + "]")[errorIndex].innerHTML = "Invalid Input";
    }
    return valid; //Return boolean
}

/*
 * @param {type} Send the current index from the loop, and the inputs from the frames
 * return a boolean
 */
function getPreviousInputs(index, balls) {
    let valid = true;
    if (index >= 2) { //If you are at the 2nd index or higher and the current frame ball has a value and the previous frame input does NOT have a value return a false
        if (balls[index].value !== "" && balls[index - 2].value === "") {
            valid = false;
        }
    }
    return valid;
}

/*
 * @param {type} Send the gameObj balls
 * return a boolean
 */
function validateFrame10(currentTeamsBall) {
    let valid = true;
    let bonusBallRegex = new RegExp(/^[\Xx,\d]/, 'i'); //Regexes for the balls
    let bonusBallRegex2 = new RegExp(/^[\/Xx,\d]/, 'i');
    //If the regex fails for frame 10's first ball, or frame 9 first ball is empty return a false
    if (!bonusBallRegex.test(currentTeamsBall[currentTeamsBall.length - 3].value) || currentTeamsBall[currentTeamsBall.length - 5].value === "") {
        valid = false;
    }
    if (!bonusBallRegex2.test(currentTeamsBall[currentTeamsBall.length - 2].value)) { //
        valid = false;
    }
    if (currentTeamsBall[currentTeamsBall.length - 3].value.toUpperCase() === "X")
    {
        if (!bonusBallRegex.test(currentTeamsBall[currentTeamsBall.length - 2].value) || !bonusBallRegex2.test(currentTeamsBall[currentTeamsBall.length - 1].value)
                || Number(currentTeamsBall[currentTeamsBall.length - 2].value) + Number(currentTeamsBall[currentTeamsBall.length - 1].value) >= 10) {
            valid = false;
        }
        if (currentTeamsBall[currentTeamsBall.length - 2].value.toUpperCase() === "X" && !bonusBallRegex.test(currentTeamsBall[currentTeamsBall.length - 1].value)) {
            valid = false;
        }
    }
    if (Number(currentTeamsBall[currentTeamsBall.length - 3].value) + Number(currentTeamsBall[currentTeamsBall.length - 2].value) >= 10) {
        valid = false;
    }
    if (currentTeamsBall[currentTeamsBall.length - 2].value === "/" && !bonusBallRegex.test(currentTeamsBall[currentTeamsBall.length - 1].value)) {
        valid = false;
    }
    return valid;
}

/*
 * @param {type} Send the inputs for frames, and the score
 */
function updateScores(currentTeam, teamScore) {
    let balls = document.querySelectorAll("[name=scores" + currentTeam + "]");
    let scoreIndex = 0;
    //If the 10th frame has a value set gameStatus to complete, otherwise set it to inprogress
    balls[balls.length - 3].value !== "" ? teamScore.gameStatusID = "COMPLETE" : teamScore.gameStatusID = "INPROGRESS"; 
    for (var i = 0; i < balls.length / 2 - 1; i++) { //Loop ball inputs
        if (i > 0) { //
            teamScore.score[i] = teamScore.score[i - 1]; //Update the team score to the previous score
        }
        //If ball is strike call ftn to do strike, otherwise add 0
        balls[scoreIndex].value.toUpperCase() === "X" ? teamScore.score[i] += Number(doStrike(balls, scoreIndex)) : teamScore.score[i] += 0;
        //If ball is strike call ftn to do spare, otherwise add 0
        balls[scoreIndex + 1].value === "/" ? teamScore.score[i] += doSpare(balls, scoreIndex) : teamScore.score[i] += 0;
        //If ball is NOT a strike  or spare call ftn to do strike, add total values
        balls[scoreIndex].value.toUpperCase() !== "X" && balls[scoreIndex + 1].value !== "/" ? teamScore.score[i] += Number(balls[scoreIndex].value) + Number(balls[scoreIndex + 1].value) : teamScore.score[i] += 0;
        scoreIndex += 2;
    }
}

/*
 * @param {type} Send the inputs for frames, and the score
 */
function doStrike(scoreArray, index) {
    res = 10; //Add 10 the total frames score
    if (index < scoreArray.length - 3) { //If you are NOT on the bonus frame do the following:
        if (scoreArray[index + 2].value.toUpperCase() === "X") { //If the next ball is a strike add 10 to the total
            res += 10;
        } else { //Otherwise add the next two balls, if its a spare add 10, otherwise add the combined totals of the balls in the next frame
            scoreArray[index + 3].value === "/" ? res += 10 : res += Number(scoreArray[index + 2].value) + Number(scoreArray[index + 3].value);
            return res; //Return the score for the frame
        }
        if (scoreArray[index + 4].value.toUpperCase() === "X") { //If the next ball for the third frame after the index is a strike add 10
            res += 10;
        } else { //Otherwise do the following:
            if (index < scoreArray.length - 5) //If you are NOT on the 9th frame and the next ball
                res += Number(scoreArray[index + 4].value);
            else { //If you are on the 9th frame and the next ball is a strike in frame 10 and the value
                scoreArray[index + 3].value.toUpperCase() === "X" ? res += 10 : res += Number(scoreArray[index + 3].value);
            }
        }
    }//end validation for checking if you are on the bonus frame
    else { //IF you are on frame 10
        if (scoreArray[index + 1].value.toUpperCase() === "X") { //If the next ball on frame 10 is a strike add 10
            res += 10;
            if (scoreArray[index + 2].value.toUpperCase() === "X") //If the last ball in frame 10 is a strike add 10  
                res += 10;
            else //If the next ball is NOT a strike add the value of the ball
                res += Number(scoreArray[index + 2].value);
        } else { //If the next ball on frame 10 is NOT a strike check to see if the next ball is a spare, if its not add the values of of the numbers
            scoreArray[index + 2].value === "/" ? res += 10 : res += Number(scoreArray[index + 1].value) + Number(scoreArray[index + 2].value);
        }
    }
    return res; //Return the total score
}

/*
 * @param {type} Send team currentBall index and the score
 * return score
 */
function doSpare(scoreArray, index) {
    res = 10; //add 10 the score
    scoreArray[index + 2].value.toUpperCase() === "X" ? res += 10 : res += Number(scoreArray[index + 2].value); //If the next ball is a strike add 10, otherwise add value
    return res;
}

function enableInputForStrike(e) {
    e.srcElement.parentElement.nextSibling.nextSibling.classList.add("hidden");
    let nextBall = e.srcElement.parentElement.nextSibling.lastChild.value;
    if (e.data !== null && nextBall !== null && e.data.toUpperCase() === "X" || nextBall === "/") { //If the current input is a strike and the next input is a spare unhide the input
        e.srcElement.parentElement.nextSibling.nextSibling.classList.remove("hidden");
        e.srcElement.parentElement.nextSibling.nextSibling.classList.add("bonus2");
        e.srcElement.parentElement.nextSibling.nextSibling.lastElementChild.value = "";
    }
}
function enableInputForSpare(e) {
    e.srcElement.parentElement.nextSibling.classList.add("hidden");
    let previousBall = e.srcElement.parentElement.previousElementSibling.firstChild.value;
    if (e.data !== null && previousBall !== null && e.data === "/" || previousBall.toUpperCase() === "X") { //If the previous input is a strike and the current index is a spare unhide the input
        e.srcElement.parentElement.nextSibling.classList.remove("hidden");
        e.srcElement.parentElement.nextSibling.classList.add("bonus2");
        e.srcElement.parentElement.nextSibling.lastElementChild.value = "";
    }
}

function updateGame(gameObj) {
    var url = "gameService/games/" + gameObj.gameID;
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            var resp = xmlhttp.responseText;
            if (resp.search("ERROR") >= 0 || resp != 1) {
                alert("Game ID: " + gameObj.gameID + " was not successsfully updated.");
            } else {
                alert("Game ID: " + gameObj.gameID + " was successsfully updated.");
                getAllMatches();
            }
        }
    };
    xmlhttp.open("PUT", url, true);
    xmlhttp.send(JSON.stringify(gameObj));
}