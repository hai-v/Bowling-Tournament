<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <script src="matchup.js"></script>
         <link rel="stylesheet" href="scorekeeper.css">
        <title></title>
    </head>
    <body img src="/images/background.jpg">
        <button id="GetButton">All Matches</button>
<!--        <select id="rounds"></select>-->
        <table id="scoreTable"></table>
    </body>
</html>
